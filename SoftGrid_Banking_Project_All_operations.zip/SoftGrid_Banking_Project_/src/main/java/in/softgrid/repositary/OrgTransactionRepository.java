package in.softgrid.repositary;

import java.util.List;

import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import in.softgrid.entity.OrgTransaction;
import in.softgrid.entity.Transaction;

@Repository
public interface OrgTransactionRepository extends JpaRepository<OrgTransaction, Long> {

    List<OrgTransaction> findByOrgAccountId(Long orgAccountId);

	
    @Query("SELECT t FROM OrgTransaction t WHERE t.orgAccount.id = :accountId ORDER BY t.orgTransactionDate DESC")
    OrgTransaction findLastTransactionByOrgAccountId(@Param("accountId") Long accountId);

    
    @Query("SELECT t FROM OrgTransaction t WHERE t.orgAccount.orgAccountNo = :orgAccountNo ORDER BY t.id DESC")
    List<OrgTransaction> findLatestTransactionForAccount(@Param("orgAccountNo") String orgAccountNo, Pageable pageable);
}



